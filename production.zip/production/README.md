# CLDR Pre-Production Data

This directory contains derived data from the [CLDR](https://github.com/unicode-org/cldr.git) project.

## LICENSE

See [LICENSE.txt](./LICENSE.txt)

>Copyright © 2019-2022 Unicode, Inc. All rights reserved.
>Distributed under the Terms of Use in https://www.unicode.org/copyright.html